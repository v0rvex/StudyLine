// lib/app_state.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'api.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

class AppState extends ChangeNotifier {
  String? _token;
  int? teacherId;
  int? pinnedGroupId;
  ThemeMode themeMode = ThemeMode.system;

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;

  AppState() {
    _load();
  }

  bool get isLogged => _token != null;
  bool get hasPinnedGroup => pinnedGroupId != null;

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('token');
    teacherId = prefs.getInt('teacherId');
    pinnedGroupId = prefs.getInt('pinnedGroupId');
    final stored = prefs.getString('themeMode');
    if (stored == 'light') themeMode = ThemeMode.light;
    if (stored == 'dark') themeMode = ThemeMode.dark;
    if (_token != null) Api.setToken(_token);
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode m) async {
    themeMode = m;
    final prefs = await SharedPreferences.getInstance();
    if (m == ThemeMode.system) {
      await prefs.remove('themeMode');
    } else {
      await prefs.setString('themeMode', m == ThemeMode.light ? 'light' : 'dark');
    }
    notifyListeners();
  }

  Future<void> loginTeacher(String login, String password) async {
    final res = await Api.login(login, password);
    final token = res['token'] as String?;
    final id = res['id'] != null ? (res['id'] as num).toInt() : null;
    if (token != null) {
      _token = token;
      teacherId = id;
      Api.setToken(_token);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('token', token);
      if (id != null) await prefs.setInt('teacherId', id);
      if (id != null) await _messaging.subscribeToTopic('teacher$id');
      // When teacher logs in, clear pinned group (teacher shouldn't auto-pin)
      await savePinnedGroup(null);
      notifyListeners();
    } else {
      throw Exception('login failed');
    }
  }

  Future<void> logoutTeacher() async {
    if (_token != null) {
      try { await Api.logout(_token!); } catch (_) {}
    }
    if (teacherId != null) await _messaging.unsubscribeFromTopic('teacher${teacherId}');
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    await prefs.remove('teacherId');
    _token = null;
    teacherId = null;
    Api.setToken(null);
    notifyListeners();
  }

  Future<void> savePinnedGroup(int? id) async {
    final prefs = await SharedPreferences.getInstance();
    if (id == null) await prefs.remove('pinnedGroupId'); else await prefs.setInt('pinnedGroupId', id);
    pinnedGroupId = id;
    notifyListeners();
  }

  Future<void> subscribeGroup(int id) async {
    try { await _messaging.subscribeToTopic('group$id'); } catch (_) {}
  }
  Future<void> unsubscribeGroup(int id) async {
    try { await _messaging.unsubscribeFromTopic('group$id'); } catch (_) {}
  }

  // single-time cache notice flag per group
  Future<bool> hasShownCacheNotice(int groupId) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('shown_cache_$groupId') ?? false;
  }
  Future<void> setShownCacheNotice(int groupId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('shown_cache_$groupId', true);
  }
}
