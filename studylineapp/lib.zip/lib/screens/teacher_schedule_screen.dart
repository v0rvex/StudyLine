// lib/screens/teacher_schedule_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import '../api.dart';
import '../widgets/custom_appbar.dart';
import '../utils.dart';

class TeacherScheduleScreen extends StatefulWidget {
  final int teacherId;
  const TeacherScheduleScreen({super.key, required this.teacherId});

  @override
  State<TeacherScheduleScreen> createState() => _TeacherScheduleScreenState();
}

class _TeacherScheduleScreenState extends State<TeacherScheduleScreen> {
  bool loading = true;
  List<Map<String, dynamic>> pairs = [];
  Map<int, String> subjects = {};
  Timer? poller;

  @override
  void initState() {
    super.initState();
    _load();
    poller = Timer.periodic(const Duration(seconds: 15), (_) => _load());
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final allGroups = await Api.getGroups();
      final subjMap = <int, String>{};
      final found = <Map<String,dynamic>>[];
      for (var g in allGroups) {
        final gid = (g['id'] as num).toInt();
        final subs = await Api.getSubjectsByGroup(gid);
        subjMap.addAll(subs);
        final sched = await Api.getSchedule(gid);
        final ch = await Api.getScheduleChanges(gid);
        for (var day in sched) {
          final weekday = (day['weekday'] as num?)?.toInt() ?? 1;
          final rawPairs = (day['pairs'] as List).cast<Map<String,dynamic>>();
          final applied = applyChangesToPairs(rawPairs, ch);
          for (var p in applied) {
            final tid = (p['teacher_id'] as num?)?.toInt();
            if (tid != null && tid == widget.teacherId) {
              final map = Map<String,dynamic>.from(p);
              map['group_id'] = gid;
              map['weekday'] = weekday;
              final change = ch.firstWhere((c) => c['schedule_id'] == p['id'], orElse: () => {});
              if (change.isNotEmpty) map['__change'] = change;
              found.add(map);
            }
          }
        }
      }
      setState(() {
        subjects = subjMap;
        pairs = found;
        loading = false;
      });
    } catch (e) {
      debugPrint('teacher load error: $e');
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void dispose() {
    poller?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const ModernAppBar(title: 'Моё расписание (учитель)', showBackButton: true),
      body: loading ? const Center(child: CircularProgressIndicator()) : ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: pairs.length,
        itemBuilder: (_, i) {
          final p = pairs[i];
          final subj = (p['subject_id'] != null) ? (subjects[(p['subject_id'] as num).toInt()] ?? '') : '';
          final gid = (p['group_id'] as num).toInt();
          final weekday = p['weekday'] ?? 1;
          final time = '${p['start_time'] ?? ''} — ${p['end_time'] ?? ''}';
          final change = p['__change'] as Map<String,dynamic>?;

          BoxDecoration deco = BoxDecoration(borderRadius: BorderRadius.circular(12), color: Theme.of(context).canvasColor);
          if (change != null) {
            final isCancelled = change['is_canceled'] == true;
            final isParallel = (change['is_parallel'] == true) || (change['is_parralel'] == true);
            final isReplacement = change['new_subject_id'] != null || change['new_teacher_id'] != null;
            if (isCancelled) {
              deco = deco.copyWith(border: Border.all(color: Colors.redAccent), color: Colors.red.withOpacity(0.06));
            } else if (isParallel) {
              deco = deco.copyWith(border: Border.all(color: Colors.yellow.shade700, width: 2));
            } else if (isReplacement) {
              deco = deco.copyWith(border: Border.all(color: Colors.white, width: 1.5));
            }
          }

          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Container(
              decoration: deco,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(subj, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Theme.of(context).colorScheme.onBackground)),
                    const SizedBox(height: 6),
                    Text('Группа $gid · День $weekday', style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withOpacity(0.75))),
                  ])),
                  Column(crossAxisAlignment: CrossAxisAlignment.end, children: [ Text(time, style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withOpacity(0.85))) ]),
                ]),
              ),
            ),
          );
        },
      ),
    );
  }
}
