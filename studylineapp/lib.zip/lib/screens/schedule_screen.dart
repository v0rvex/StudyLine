// lib/screens/schedule_screen.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../api.dart';
import '../app_state.dart';
import '../utils.dart';
import '../widgets/nice_cards.dart';
import '../widgets/custom_appbar.dart';

class ScheduleScreen extends StatefulWidget {
  final int groupId;
  final String groupName;
  const ScheduleScreen({super.key, required this.groupId, required this.groupName});

  @override
  State<ScheduleScreen> createState() => _ScheduleScreenState();
}

class _ScheduleScreenState extends State<ScheduleScreen> with WidgetsBindingObserver {
  List<Map<String, dynamic>> schedule = [];
  Map<int, String> subjects = {};
  Map<int, String> teachers = {};
  List<Map<String, dynamic>> changes = [];
  bool _firstLoad = true;
  bool _isRefreshing = false;
  Timer? poller;
  bool _showNoNetBanner = false;
  bool _hasShownCacheNotice = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkCacheNoticeFlag();
    _loadFromCacheThenNetwork();
    poller = Timer.periodic(const Duration(seconds: 15), (_) => _loadAll());
  }

  Future<void> _checkCacheNoticeFlag() async {
    final app = Provider.of<AppState>(context, listen: false);
    final shown = await app.hasShownCacheNotice(widget.groupId);
    setState(() { _hasShownCacheNotice = shown; });
  }

  Future<void> _loadFromCacheThenNetwork() async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'schedule_cache_${widget.groupId}';
    final cached = prefs.getString(key);
    if (cached != null && cached.isNotEmpty) {
      try {
        final j = jsonDecode(cached) as Map<String, dynamic>;
        setState(() {
          schedule = List<Map<String, dynamic>>.from(j['schedule'] ?? []);
          subjects = Map<int, String>.from(j['subjects'] ?? {});
          teachers = Map<int, String>.from(j['teachers'] ?? {});
          changes = List<Map<String, dynamic>>.from(j['changes'] ?? []);
          _firstLoad = false;
        });
        if (!_hasShownCacheNotice) {
          final app = Provider.of<AppState>(context, listen: false);
          await app.setShownCacheNotice(widget.groupId);
          setState(() { _hasShownCacheNotice = true; });
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Нет сети — показан кэш')));
        }
      } catch (_) {}
    }
    await _loadAll();
  }

  Future<void> _loadAll() async {
    setState(() { _isRefreshing = true; });
    final prefs = await SharedPreferences.getInstance();
    final cacheKey = 'schedule_cache_${widget.groupId}';
    try {
      final subj = await Api.getSubjectsByGroup(widget.groupId);
      final t = await Api.getTeachers();
      final sched = await Api.getSchedule(widget.groupId);
      final ch = await Api.getScheduleChanges(widget.groupId);

      final mapToStore = {'schedule': sched, 'subjects': subj, 'teachers': t, 'changes': ch};
      await prefs.setString(cacheKey, jsonEncode(mapToStore));

      if (mounted) setState(() {
        subjects = subj;
        teachers = t;
        schedule = sched;
        changes = ch;
        _firstLoad = false;
        _showNoNetBanner = false;
      });
    } catch (e) {
      debugPrint('schedule load error: $e');
      if (mounted) {
        setState(() {
          _firstLoad = false;
          _showNoNetBanner = true;
        });
      }
    } finally {
      // delay short to avoid flashing top bar for quick loads
      await Future.delayed(const Duration(milliseconds: 200));
      if (mounted) setState(() { _isRefreshing = false; });
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      poller?.cancel();
      poller = null;
    } else if (state == AppLifecycleState.resumed && poller == null) {
      poller = Timer.periodic(const Duration(seconds: 15), (_) => _loadAll());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    poller?.cancel();
    final app = Provider.of<AppState>(context, listen: false);
    // unsubscribe on leaving screen — handled in previous design
    app.unsubscribeGroup(widget.groupId);
    super.dispose();
  }

  String weekdayName(int w) {
    const names = ['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье'];
    return names[(w-1).clamp(0,6)];
  }

  List<Map<String,dynamic>> _applyChanges(List<Map<String,dynamic>> pairs) => applyChangesToPairs(pairs, changes);

  @override
  Widget build(BuildContext context) {
    final app = Provider.of<AppState>(context);
    final fg = Theme.of(context).colorScheme.onBackground;

    // show back only if teacher
    final showBack = app.isLogged;

    return Scaffold(
      appBar: ModernAppBar(title: widget.groupName.isNotEmpty ? widget.groupName : 'Расписание', showBackButton: showBack, onBack: () {
        if (showBack) Navigator.of(context).pop();
      }),
      body: SafeArea(
        child: Stack(children: [
          if (_firstLoad) const Center(child: CircularProgressIndicator()),
          if (!_firstLoad) LayoutBuilder(builder: (context, constraints) {
            final isLandscape = constraints.maxWidth > constraints.maxHeight;
            // in landscape try to show all days in two columns to avoid scrolling
            if (isLandscape) {
              return _buildLandscapeGrid(constraints);
            } else {
              return RefreshIndicator(
                onRefresh: _loadAll,
                child: ListView(padding: const EdgeInsets.all(12), children: [
                  for (final day in schedule) _dayCard(day, fg),
                  const SizedBox(height: 24),
                ]),
              );
            }
          }),
          if (_isRefreshing) Positioned(top: 0, left: 0, right: 0, child: LinearProgressIndicator(minHeight: 3, color: Theme.of(context).colorScheme.primary)),
          // animated no-network banner
          AnimatedPositioned(
            duration: const Duration(milliseconds: 300),
            top: _showNoNetBanner ? 0 : -60,
            left: 0,
            right: 0,
            height: 56,
            child: Container(
              color: Colors.orange.shade700,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(children: const [
                Icon(Icons.wifi_off, color: Colors.white),
                SizedBox(width: 12),
                Expanded(child: Text('Нет сети — показан кэш (если доступен)', style: TextStyle(color: Colors.white))),
              ]),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildLandscapeGrid(BoxConstraints constraints) {
    // Show days in two columns grid and scale content so it fits
    final cols = 2;
    final rows = (schedule.length / cols).ceil();
    final childWidth = constraints.maxWidth / cols;
    final childHeight = constraints.maxHeight / rows;
    final itemSize = Size(childWidth, childHeight);
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: cols, childAspectRatio: childWidth / childHeight),
      itemCount: schedule.length,
      itemBuilder: (_, i) {
        final day = schedule[i];
        return Padding(padding: const EdgeInsets.all(6), child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: Theme.of(context).cardColor),
          child: SingleChildScrollView( // still allow content inside card to scroll if extreme case
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(weekdayName((day['weekday'] as num?)?.toInt() ?? 1), style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.onBackground)),
              const SizedBox(height: 8),
              ...((day['pairs'] as List? ?? []).cast<Map<String,dynamic>>()).map((p) {
                final sid = (p['subject_id'] as num?)?.toInt();
                final tid = (p['teacher_id'] as num?)?.toInt();
                final subj = sid != null ? (subjects[sid] ?? '') : '';
                final teacher = tid != null ? (teachers[tid] ?? '') : '';
                final time = '${p['start_time'] ?? ''} — ${p['end_time'] ?? ''}';
                final cab = p['cabinet'] ?? '';
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(subj, style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text('$teacher · $cab', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                    const SizedBox(height: 4),
                    Text(time, style: const TextStyle(fontSize: 12)),
                  ]),
                );
              }).toList(),
            ]),
          ),
        ));
      },
    );
  }

  Widget _dayCard(Map<String, dynamic> day, Color fg) {
    final weekday = (day['weekday'] is num) ? (day['weekday'] as num).toInt() : 1;
    final rawPairs = (day['pairs'] as List? ?? []).cast<Map<String,dynamic>>();
    final pairs = _applyChanges(rawPairs);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 6),
      Text(weekdayName(weekday), style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: fg)),
      const SizedBox(height: 8),
      ...pairs.map((p) {
        final sid = (p['subject_id'] as num?)?.toInt();
        final tid = (p['teacher_id'] as num?)?.toInt();
        final subj = sid != null ? (subjects[sid] ?? '') : '';
        final teacher = tid != null ? (teachers[tid] ?? '') : '';
        final time = '${p['start_time'] ?? ''} — ${p['end_time'] ?? ''}';
        final cab = p['cabinet'] ?? '';
        final change = changes.firstWhere((c) => c['schedule_id'] == p['id'], orElse: () => {});
        final isCanceled = change.isNotEmpty && (change['is_canceled'] == true);
        final isParallel = change.isNotEmpty && ((change['is_parallel'] == true) || (change['is_parralel'] == true));
        final replaced = change.isNotEmpty && (change['new_subject_id'] != null || change['new_teacher_id'] != null);

        BoxDecoration dec = BoxDecoration(borderRadius: BorderRadius.circular(12), color: Theme.of(context).canvasColor);
        if (isCanceled) dec = dec.copyWith(color: Colors.red.withOpacity(0.08), border: Border.all(color: Colors.redAccent));
        else if (replaced) dec = dec.copyWith(border: Border.all(color: Colors.white));
        // no parallel highlight for group schedule

        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Container(
            decoration: dec,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(subj, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: fg)),
                  const SizedBox(height: 6),
                  Text(teacher, style: TextStyle(fontSize: 13, color: fg.withOpacity(0.8))),
                  const SizedBox(height: 6),
                  if (cab.isNotEmpty) Text('Каб.: $cab', style: TextStyle(fontSize: 12, color: fg.withOpacity(0.6))),
                ])),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(time, style: TextStyle(fontSize: 13, color: fg.withOpacity(0.8))),
                ]),
              ]),
            ),
          ),
        );
      }).toList(),
      const SizedBox(height: 10),
    ]);
  }
}
