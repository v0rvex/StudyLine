// lib/utils.dart
import 'package:intl/intl.dart';

DateTime parseDate(String? s) {
  if (s == null) return DateTime.now();
  try {
    return DateTime.parse(s);
  } catch (_) {
    return DateTime.now();
  }
}

/// Мержим расписание + изменения: если change.countains(schedule_id) — заменяем поля.
/// Упрощённо: возвращаем список pairs с применёнными заменами (работает если change содержит schedule_id)
List<Map<String, dynamic>> applyChangesToPairs(List<Map<String, dynamic>> pairs, List<Map<String, dynamic>> changes) {
  final out = <Map<String, dynamic>>[];
  for (var p in pairs) {
    final id = p['id'];
    final change = changes.firstWhere(
          (c) => c['schedule_id'] == id,
      orElse: () => {},
    );
    if (change.isNotEmpty) {
      if (change['is_canceled'] == true) {
        // skip (cancelled)
        continue;
      }
      final copy = Map<String, dynamic>.from(p);
      if (change['new_subject_id'] != null) copy['subject_id'] = change['new_subject_id'];
      if (change['new_teacher_id'] != null) copy['teacher_id'] = change['new_teacher_id'];
      if (change['new_start_time'] != null) copy['start_time'] = change['new_start_time'];
      if (change['new_end_time'] != null) copy['end_time'] = change['new_end_time'];
      if (change['cabinet'] != null) copy['cabinet'] = change['cabinet'];
      out.add(copy);
    } else {
      out.add(p);
    }
  }
  return out;
}
